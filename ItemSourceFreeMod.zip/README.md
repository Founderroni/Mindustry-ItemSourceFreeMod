Created by me, Founder

You can use the item source block in any gamemode with this mod enabled.

Discord: HNU Founder.lua#5046